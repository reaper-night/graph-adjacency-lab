#ifndef ADJACENCY_MATRIX_H
#define ADJACENCY_MATRIX_H

#include <stdbool.h>

#define MAX_VERTEX_NUM 20

typedef struct {
    char data;
} VertexType;

typedef struct {
    VertexType vertices[MAX_VERTEX_NUM];
    int edges[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
    int vertexCount;
    int edgeCount;
    bool directed;
} AdjacencyMatrix;

AdjacencyMatrix* am_create(bool directed);
void am_destroy(AdjacencyMatrix* graph);
int am_addVertex(AdjacencyMatrix* graph, char data);
int am_removeVertex(AdjacencyMatrix* graph, int index);
int am_updateVertex(AdjacencyMatrix* graph, int index, char newData);
int am_findVertex(AdjacencyMatrix* graph, char data);
char am_getVertex(AdjacencyMatrix* graph, int index);
int am_addEdge(AdjacencyMatrix* graph, int from, int to, int weight);
int am_removeEdge(AdjacencyMatrix* graph, int from, int to);
int am_updateEdge(AdjacencyMatrix* graph, int from, int to, int newWeight);
int am_getEdge(AdjacencyMatrix* graph, int from, int to);
void am_print(AdjacencyMatrix* graph);
void am_dfs(AdjacencyMatrix* graph, int start);

#endif
