#include "adjacency_matrix.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void am_initEdges(AdjacencyMatrix* graph) {
    int i, j;
    for (i = 0; i < MAX_VERTEX_NUM; i++) {
        for (j = 0; j < MAX_VERTEX_NUM; j++) {
            graph->edges[i][j] = 0;
        }
    }
}

AdjacencyMatrix* am_create(bool directed) {
    AdjacencyMatrix* graph = (AdjacencyMatrix*)malloc(sizeof(AdjacencyMatrix));
    if (graph == NULL) {
        printf("Memory allocation failed for AdjacencyMatrix\n");
        return NULL;
    }
    graph->vertexCount = 0;
    graph->edgeCount = 0;
    graph->directed = directed;
    am_initEdges(graph);
    return graph;
}

void am_destroy(AdjacencyMatrix* graph) {
    if (graph != NULL) {
        free(graph);
    }
}

int am_addVertex(AdjacencyMatrix* graph, char data) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (graph->vertexCount >= MAX_VERTEX_NUM) {
        printf("Error: maximum vertex capacity reached\n");
        return -1;
    }
    graph->vertices[graph->vertexCount].data = data;
    return graph->vertexCount++;
}

int am_removeVertex(AdjacencyMatrix* graph, int index) {
    int i;
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (index < 0 || index >= graph->vertexCount) {
        printf("Error: invalid vertex index %d\n", index);
        return -1;
    }

    for (i = index; i < graph->vertexCount - 1; i++) {
        graph->vertices[i] = graph->vertices[i + 1];
    }

    for (i = index; i < graph->vertexCount - 1; i++) {
        int j;
        for (j = 0; j < graph->vertexCount; j++) {
            graph->edges[i][j] = graph->edges[i + 1][j];
        }
    }

    for (i = 0; i < graph->vertexCount; i++) {
        int j;
        for (j = index; j < graph->vertexCount - 1; j++) {
            graph->edges[i][j] = graph->edges[i][j + 1];
        }
    }

    for (i = 0; i < graph->vertexCount; i++) {
        graph->edges[i][graph->vertexCount - 1] = 0;
    }
    for (i = 0; i < graph->vertexCount; i++) {
        graph->edges[graph->vertexCount - 1][i] = 0;
    }

    graph->vertexCount--;
    return 0;
}

int am_updateVertex(AdjacencyMatrix* graph, int index, char newData) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (index < 0 || index >= graph->vertexCount) {
        printf("Error: invalid vertex index %d\n", index);
        return -1;
    }
    graph->vertices[index].data = newData;
    return 0;
}

int am_findVertex(AdjacencyMatrix* graph, char data) {
    int i;
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    for (i = 0; i < graph->vertexCount; i++) {
        if (graph->vertices[i].data == data) {
            return i;
        }
    }
    return -1;
}

char am_getVertex(AdjacencyMatrix* graph, int index) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return '\0';
    }
    if (index < 0 || index >= graph->vertexCount) {
        printf("Error: invalid vertex index %d\n", index);
        return '\0';
    }
    return graph->vertices[index].data;
}

int am_addEdge(AdjacencyMatrix* graph, int from, int to, int weight) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (from < 0 || from >= graph->vertexCount || to < 0 || to >= graph->vertexCount) {
        printf("Error: invalid vertex indices (%d, %d)\n", from, to);
        return -1;
    }
    if (graph->edges[from][to] != 0) {
        printf("Warning: edge (%d, %d) already exists, updating weight\n", from, to);
    }
    graph->edges[from][to] = weight;
    if (!graph->directed && from != to) {
        graph->edges[to][from] = weight;
    }
    graph->edgeCount++;
    return 0;
}

int am_removeEdge(AdjacencyMatrix* graph, int from, int to) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (from < 0 || from >= graph->vertexCount || to < 0 || to >= graph->vertexCount) {
        printf("Error: invalid vertex indices (%d, %d)\n", from, to);
        return -1;
    }
    if (graph->edges[from][to] == 0) {
        printf("Error: edge (%d, %d) does not exist\n", from, to);
        return -1;
    }
    graph->edges[from][to] = 0;
    if (!graph->directed && from != to) {
        graph->edges[to][from] = 0;
    }
    graph->edgeCount--;
    return 0;
}

int am_updateEdge(AdjacencyMatrix* graph, int from, int to, int newWeight) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (from < 0 || from >= graph->vertexCount || to < 0 || to >= graph->vertexCount) {
        printf("Error: invalid vertex indices (%d, %d)\n", from, to);
        return -1;
    }
    if (graph->edges[from][to] == 0) {
        printf("Error: edge (%d, %d) does not exist\n", from, to);
        return -1;
    }
    graph->edges[from][to] = newWeight;
    if (!graph->directed && from != to) {
        graph->edges[to][from] = newWeight;
    }
    return 0;
}

int am_getEdge(AdjacencyMatrix* graph, int from, int to) {
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return -1;
    }
    if (from < 0 || from >= graph->vertexCount || to < 0 || to >= graph->vertexCount) {
        printf("Error: invalid vertex indices (%d, %d)\n", from, to);
        return -1;
    }
    return graph->edges[from][to];
}

void am_print(AdjacencyMatrix* graph) {
    int i, j;
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return;
    }
    printf("\nAdjacency Matrix Graph (%s):\n", graph->directed ? "directed" : "undirected");
    printf("Vertices: %d, Edges: %d\n", graph->vertexCount, graph->edgeCount);
    printf("Vertex labels: ");
    for (i = 0; i < graph->vertexCount; i++) {
        printf("%c ", graph->vertices[i].data);
    }
    printf("\n\nMatrix:\n  ");
    for (i = 0; i < graph->vertexCount; i++) {
        printf(" %c", graph->vertices[i].data);
    }
    printf("\n");
    for (i = 0; i < graph->vertexCount; i++) {
        printf("%c ", graph->vertices[i].data);
        for (j = 0; j < graph->vertexCount; j++) {
            printf("%2d", graph->edges[i][j]);
        }
        printf("\n");
    }
}

static void am_dfsHelper(AdjacencyMatrix* graph, int start, bool* visited) {
    int i;
    printf("%c ", graph->vertices[start].data);
    visited[start] = true;
    for (i = 0; i < graph->vertexCount; i++) {
        if (graph->edges[start][i] != 0 && !visited[i]) {
            am_dfsHelper(graph, i, visited);
        }
    }
}

void am_dfs(AdjacencyMatrix* graph, int start) {
    bool visited[MAX_VERTEX_NUM];
    int i;
    if (graph == NULL) {
        printf("Error: graph is NULL\n");
        return;
    }
    if (start < 0 || start >= graph->vertexCount) {
        printf("Error: invalid start vertex index %d\n", start);
        return;
    }
    for (i = 0; i < MAX_VERTEX_NUM; i++) {
        visited[i] = false;
    }
    printf("DFS traversal starting from %c: ", graph->vertices[start].data);
    am_dfsHelper(graph, start, visited);
    printf("\n");

    for (i = 0; i < graph->vertexCount; i++) {
        if (!visited[i]) {
            printf("DFS traversal (unconnected component) starting from %c: ", graph->vertices[i].data);
            am_dfsHelper(graph, i, visited);
            printf("\n");
        }
    }
}
