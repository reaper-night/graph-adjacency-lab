#include <stdio.h>
#include "adjacency_matrix.h"
#include "adjacency_list.h"

void testAdjacencyMatrix() {
    printf("=====================================\n");
    printf("    Testing Adjacency Matrix Graph   \n");
    printf("=====================================\n");

    AdjacencyMatrix* graph = am_create(false);
    if (graph == NULL) {
        printf("Failed to create adjacency matrix graph\n");
        return;
    }

    printf("\n1. Adding vertices...\n");
    am_addVertex(graph, 'A');
    am_addVertex(graph, 'B');
    am_addVertex(graph, 'C');
    am_addVertex(graph, 'D');
    am_addVertex(graph, 'E');
    am_print(graph);

    printf("\n2. Adding edges...\n");
    am_addEdge(graph, 0, 1, 10);
    am_addEdge(graph, 0, 2, 20);
    am_addEdge(graph, 1, 3, 30);
    am_addEdge(graph, 2, 3, 40);
    am_addEdge(graph, 3, 4, 50);
    am_print(graph);

    printf("\n3. Finding vertex...\n");
    int idx = am_findVertex(graph, 'C');
    printf("Index of vertex 'C': %d\n", idx);

    printf("\n4. Getting edge weight...\n");
    int weight = am_getEdge(graph, 0, 1);
    printf("Weight of edge (A, B): %d\n", weight);

    printf("\n5. Updating vertex...\n");
    am_updateVertex(graph, 4, 'F');
    am_print(graph);

    printf("\n6. Updating edge weight...\n");
    am_updateEdge(graph, 0, 1, 100);
    am_print(graph);

    printf("\n7. DFS traversal...\n");
    am_dfs(graph, 0);

    printf("\n8. Removing edge...\n");
    am_removeEdge(graph, 0, 2);
    am_print(graph);

    printf("\n9. Removing vertex...\n");
    am_removeVertex(graph, 1);
    am_print(graph);

    printf("\n10. DFS after modifications...\n");
    am_dfs(graph, 0);

    am_destroy(graph);
}

void testAdjacencyList() {
    printf("\n\n=====================================\n");
    printf("     Testing Adjacency List Graph    \n");
    printf("=====================================\n");

    AdjacencyList* graph = al_create(false);
    if (graph == NULL) {
        printf("Failed to create adjacency list graph\n");
        return;
    }

    printf("\n1. Adding vertices...\n");
    al_addVertex(graph, 'A');
    al_addVertex(graph, 'B');
    al_addVertex(graph, 'C');
    al_addVertex(graph, 'D');
    al_addVertex(graph, 'E');
    al_print(graph);

    printf("\n2. Adding edges...\n");
    al_addEdge(graph, 0, 1, 10);
    al_addEdge(graph, 0, 2, 20);
    al_addEdge(graph, 1, 3, 30);
    al_addEdge(graph, 2, 3, 40);
    al_addEdge(graph, 3, 4, 50);
    al_print(graph);

    printf("\n3. Finding vertex...\n");
    int idx = al_findVertex(graph, 'C');
    printf("Index of vertex 'C': %d\n", idx);

    printf("\n4. Getting edge weight...\n");
    int weight = al_getEdge(graph, 0, 1);
    printf("Weight of edge (A, B): %d\n", weight);

    printf("\n5. Updating vertex...\n");
    al_updateVertex(graph, 4, 'F');
    al_print(graph);

    printf("\n6. Updating edge weight...\n");
    al_updateEdge(graph, 0, 1, 100);
    al_print(graph);

    printf("\n7. DFS traversal...\n");
    al_dfs(graph, 0);

    printf("\n8. Removing edge...\n");
    al_removeEdge(graph, 0, 2);
    al_print(graph);

    printf("\n9. Removing vertex...\n");
    al_removeVertex(graph, 1);
    al_print(graph);

    printf("\n10. DFS after modifications...\n");
    al_dfs(graph, 0);

    al_destroy(graph);
}

void testDirectedGraphs() {
    printf("\n\n=====================================\n");
    printf("       Testing Directed Graphs       \n");
    printf("=====================================\n");

    printf("\n--- Directed Adjacency Matrix ---\n");
    AdjacencyMatrix* dmGraph = am_create(true);
    am_addVertex(dmGraph, 'X');
    am_addVertex(dmGraph, 'Y');
    am_addVertex(dmGraph, 'Z');
    am_addEdge(dmGraph, 0, 1, 5);
    am_addEdge(dmGraph, 1, 2, 8);
    am_addEdge(dmGraph, 2, 0, 3);
    am_print(dmGraph);
    printf("\nDFS on directed matrix graph:\n");
    am_dfs(dmGraph, 0);
    am_destroy(dmGraph);

    printf("\n--- Directed Adjacency List ---\n");
    AdjacencyList* dlGraph = al_create(true);
    al_addVertex(dlGraph, 'X');
    al_addVertex(dlGraph, 'Y');
    al_addVertex(dlGraph, 'Z');
    al_addEdge(dlGraph, 0, 1, 5);
    al_addEdge(dlGraph, 1, 2, 8);
    al_addEdge(dlGraph, 2, 0, 3);
    al_print(dlGraph);
    printf("\nDFS on directed list graph:\n");
    al_dfs(dlGraph, 0);
    al_destroy(dlGraph);
}

void testErrorHandling() {
    printf("\n\n=====================================\n");
    printf("        Testing Error Handling       \n");
    printf("=====================================\n");

    printf("\n--- Testing invalid operations ---\n");

    AdjacencyMatrix* graph = am_create(false);
    am_addVertex(graph, 'A');
    am_addVertex(graph, 'B');

    printf("\nAttempting to add edge with invalid vertex index:\n");
    am_addEdge(graph, 0, 10, 10);

    printf("\nAttempting to remove non-existent edge:\n");
    am_removeEdge(graph, 0, 1);

    printf("\nAttempting to update non-existent vertex:\n");
    am_updateVertex(graph, 5, 'Z');

    printf("\nAttempting to find non-existent vertex:\n");
    int idx = am_findVertex(graph, 'Z');
    printf("Index of 'Z': %d (should be -1)\n", idx);

    am_destroy(graph);
}

int main() {
    printf("Graph Demo - C Language Implementation\n");
    printf("=====================================\n\n");

    testAdjacencyMatrix();
    testAdjacencyList();
    testDirectedGraphs();
    testErrorHandling();

    printf("\n\nAll tests completed successfully!\n");
    return 0;
}
