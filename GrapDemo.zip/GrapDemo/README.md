# Graph Demo - C Language Implementation

图数据结构的 C 语言实现，包含邻接矩阵和邻接表两种存储方式，支持有向图和无向图。

## 项目结构

```
GrapDemo/
├── bin/              # 编译输出目录
│   └── GrapDemo      # 可执行文件
├── include/          # 头文件目录
│   ├── adjacency_matrix.h   # 邻接矩阵接口
│   └── adjacency_list.h     # 邻接表接口
├── src/              # 源文件目录
│   ├── main.c               # 测试入口
│   ├── adjacency_matrix.c   # 邻接矩阵实现
│   └── adjacency_list.c     # 邻接表实现
└── Makefile          # 构建脚本
```

## 功能特性

### 邻接矩阵 (`AdjacencyMatrix`)

| 函数 | 功能 |
|------|------|
| `am_create()` | 创建图 |
| `am_destroy()` | 销毁图 |
| `am_addVertex()` | 添加顶点 |
| `am_removeVertex()` | 删除顶点 |
| `am_updateVertex()` | 更新顶点数据 |
| `am_findVertex()` | 查找顶点索引 |
| `am_addEdge()` | 添加边（带权） |
| `am_removeEdge()` | 删除边 |
| `am_updateEdge()` | 更新边权重 |
| `am_getEdge()` | 获取边权重 |
| `am_print()` | 打印图结构 |
| `am_dfs()` | 深度优先遍历 |

### 邻接表 (`AdjacencyList`)

| 函数 | 功能 |
|------|------|
| `al_create()` | 创建图 |
| `al_destroy()` | 销毁图 |
| `al_addVertex()` | 添加顶点 |
| `al_removeVertex()` | 删除顶点 |
| `al_updateVertex()` | 更新顶点数据 |
| `al_findVertex()` | 查找顶点索引 |
| `al_addEdge()` | 添加边（带权） |
| `al_removeEdge()` | 删除边 |
| `al_updateEdge()` | 更新边权重 |
| `al_getEdge()` | 获取边权重 |
| `al_print()` | 打印图结构 |
| `al_dfs()` | 深度优先遍历 |

## 编译运行

```bash
# 编译
make

# 运行测试
make test

# 清理
make clean
```
# gcc运行
    gcc -Wall -Wextra -std=c11 -Iinclude \
    src/main.c src/adjacency_matrix.c src/adjacency_list.c \
    -o bin/GrapDemo

    ./bin/GrapDemo

## 使用示例

```c
// 创建无向图
AdjacencyMatrix* graph = am_create(false);

// 添加顶点
am_addVertex(graph, 'A');
am_addVertex(graph, 'B');
am_addVertex(graph, 'C');

// 添加边 (A->B, weight=10)
am_addEdge(graph, 0, 1, 10);

// 深度优先遍历
am_dfs(graph, 0);

// 销毁图
am_destroy(graph);
```

## 数据结构设计

### 邻接矩阵

```
vertices: [A][B][C][D][E]
edges:    [0][10][20][0][0]
          [10][0][0][30][0]
          [20][0][0][40][0]
          [0][30][40][0][50]
          [0][0][0][50][0]
```

### 邻接表

```
A -> [B:10] -> [C:20] -> NULL
B -> [A:10] -> [D:30] -> NULL
C -> [A:20] -> [D:40] -> NULL
D -> [B:30] -> [C:40] -> [E:50] -> NULL
E -> [D:50] -> NULL
```

## 复杂度分析

| 操作 | 邻接矩阵 | 邻接表 |
|------|----------|--------|
| 添加顶点 | O(n) | O(1) |
| 删除顶点 | O(n²) | O(n+e) |
| 添加边 | O(1) | O(1) |
| 删除边 | O(1) | O(n) |
| 查询边 | O(1) | O(n) |
| DFS 遍历 | O(n²) | O(n+e) |

## 注意事项

- 顶点数量上限为 `MAX_VERTEX_NUM` (20)
- 边权重为整数类型
- 无向图添加边时会自动添加反向边
- 所有接口均包含参数有效性校验